<template>
  <div id="app">
    <YearBill v-model="isbill" v-if="isbill"/>
    <CashPlus v-else/>
  </div>
</template>

<script>
import YearBill from './components/YearBill.vue'
import CashPlus from './components/CashPlus'

export default {
  name: 'app',
  components: {
    YearBill,
    CashPlus
  },
  data () {
    return {
      isbill: true
    }
  }
}
</script>
