/* eslint-disable */
/**
 * 南方基金远程页面api
 */
window.activeInfo = {}
  // 事件类型
window.ActivityeType = {
    eIsLogin: 'nfIsLogin', // 获取是否登录事件
    eGetDetails: 'nfGetDetails', // 获取用户详情
    eSetSession: 'nfSetSession' // 设置会话缓存
  }
/**
 * 父节点事件监听
 */
window.addEventListener(
  'message',
  function(e) {
    if (e.data) {
      switch (e.data.nfEvent) {
        case ActivityeType.eIsLogin:
        case ActivityeType.eGetDetails:
        case ActivityeType.eSetSession:
          activeInfo = e.data.data
          PrivateMethod.onComplete(e.data.nfEvent, e.data.data)
          break
      }
    }
  },
  false
)
var increase = 1
var PrivateMethod = {
  callbacks: {},
  generatePort: function() {
    return Math.floor(Math.random() * (1 << 50)) + '' + increase++
  },
  registerCallback: function(port, callback) {
    if (!port) {
      port = PrivateMethod.generatePort()
    }
    if (typeof callback !== 'function') {
      callback = null
    }
    if (callback) {
      PrivateMethod.callbacks[port] = callback
    }
  },
  getCallback: function(port) {
    var call = {}
    if (PrivateMethod.callbacks[port]) {
      call.callback = PrivateMethod.callbacks[port]
    } else {
      call.callback = null
    }
    return call
  },
  unRegisterCallback: function(port) {
    if (PrivateMethod.callbacks[port]) {
      delete PrivateMethod.callbacks[port]
    }
  },
  onComplete: function(port, result) {
    var callback = PrivateMethod.getCallback(port).callback
    PrivateMethod.unRegisterCallback(port)
    if (callback) {
      // 执行回调
      callback && callback(result)
    }
  }
}
/**
 * jump page function
 * @param pageName 页面名称
 * @param params 参数
 * @param urlInfo { detailurl:'http://www.nf.com', title:'标题'} 远程url信息
 */
window.nfActivityJs =
  window.nfActivityJs || {
    goNfPage: function(pageName, params, urlInfo) {
      var data = {
        nfFlag: 'nfActivities',
        nfname: pageName,
        params: params,
        urlInfo: urlInfo
      }
      parent.postMessage(data, '*')
      return false
    },
    /**
     * 事件发送
     * @param nfEvent 事件名称
     * @param params 事件回调函数
     * @param params 参数
     */
    nfAcPostMessage: function(nfEvent, cb, params) {
      var data = {
        nfFlag: 'nfActivities',
        nfEvent: nfEvent,
        params: params
      }
      PrivateMethod.registerCallback(nfEvent, cb)
      parent.postMessage(data, '*')
      return false
    },
    /**
     * 判断是否登录 如果已登录，则返回用户信息
     @param cb(res) 获取数据的回调函数
     */
    judgeLogin: function(cb) {
      return nfActivityJs.nfAcPostMessage(ActivityeType.eIsLogin, cb)
    },
    /**
     * 显示加载toast
     */
    showLoading: function(cb) {
      return nfActivityJs.nfAcPostMessage('SHOW_LOADING', cb)
    },
    /**
     * 隐藏加载toast
     */
    hideLoading: function(cb) {
      return nfActivityJs.nfAcPostMessage('HIDE_LOADING', cb)
    },
    /**
     * toast提示信息框
     */
    toast: function(message,cb) {
      return nfActivityJs.nfAcPostMessage('Toast',cb,{message:message})
    }
  }

// 获取用户详情信息
nfActivityJs.nfAcPostMessage(ActivityeType.eGetDetails)

export {
  nfActivityJs
}
