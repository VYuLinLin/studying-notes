<template>
  <section class="bill-shell" :class="`section${index}`">
    <slot></slot>
  </section>
</template>
<script>
export default {
  name: 'BillShell',
  props: {
    index: {
      type: Number,
      default: 0
    }
  }
}
</script>
<style lang="scss" scoped>
@mixin getbjimg($url) {
  background: url('#{$imgUrl}/static/2018bill/img/bill_0#{$url}.png') no-repeat top center;
  background-size: cover;
}
section { height: 100%; position: relative; }
.section0 { @include getbjimg(0) }
.section1 { @include getbjimg(1) }
.section2 { @include getbjimg(2) }
.section3 { @include getbjimg(3) }
.section4 { @include getbjimg(4) }
.section5 { @include getbjimg(5) }
.section6 { @include getbjimg(6) }
.section7 { @include getbjimg(7) }
.section8 { @include getbjimg(8) }
.section9 { @include getbjimg(9) }

.section4 .content { margin-top: 1.6rem;}
.section5 {
  .content2 {
    color: #fff;
    top: unset !important;
    left: 2.58rem !important;
    bottom: 2.5rem;
    background: rgba(111, 99, 250, .8) !important;
  }
}
.section8 .details {
  position: absolute;
  .header {
    width: 80%;
    margin: 1.16rem auto;
    box-sizing: border-box;
    padding: 0.32rem;
    letter-spacing: 0;
    text-align: justify;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 5px;
  }
  .line-chart {
    width: 80%;
    padding: 0.32rem;
    margin: auto;
    background: #fff;
    box-sizing: border-box;
    text-align: left;
  }
}
</style>
