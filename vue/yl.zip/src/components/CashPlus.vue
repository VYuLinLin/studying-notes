<template>
  <div class="year-r">
    <div class="first-line">2018年您在南方基金活跃度较低，暂无2018年度账单，欢迎您多多体验我们的理财服务哦~
    </div>
    <div class="second-line">我们近期推出了智能化货币理财工具—<span class="red-text">现金宝+</span>
      支持智能充值、智能取现，最高快速取现
      <div>额度可达<span class="red-text">8万元</span></div>
    </div>
    <div class="center-img"></div>
    <button class="go_xjbplus" @click="nfActivityJs.goNfPage('SuperCashPlus')">体验现金宝+</button>
  </div>
</template>
<script>
export default {
  name: 'CashPlus'
}
</script>
<style lang="scss">
.year-r {
  padding: 0 0.72rem; // 36.2px
  background-color: white;
  height: 100%;
  line-height: 0.48rem; // 24px;
  font-size: 0.28rem; // 14px;
  text-align: center;
  letter-spacing: 0;
  .first-line {
    padding-top: 0.9rem; // 44.8px
    color: #333;
  }
  .second-line {
    padding-top: 0.28rem; // 14px
    color: #999;
  }
  .red-text {
    color: #F56C6E;
  }
  .center-img{
    padding-top: 0.12rem; // 5.8px
    height: 5.34rem; // 267px
    background: url('#{$imgUrl}/static/2018bill/img/cash_plus.png') no-repeat center;
    background-size: 5.78rem 5.34rem;
  }
  .go_xjbplus {
    position: fixed;
    bottom: 10%;
    left: 0;
    right: 0;
    width: 37%;
    height: 0.7rem;
    line-height: 0.7rem; // 35px
    color: #fff;
    background: #F56C6E;
    border-radius: 0.35rem; // 17.5px
    font-size: 0.36rem; // 18px
    margin: 0 auto;
  }
}
</style>
