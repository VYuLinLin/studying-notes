<template>
  <div id="chart"></div>
</template>
<script>
let myChart
// 引入基本模板
let echarts = require('echarts/lib/echarts')
require('echarts/lib/chart/line')
export default {
  name: 'LineChart',
  props: {
    data: {
      type: Array,
      default () {
        return []
      }
    }
  },
  mounted () {
    this.init()
  },
  methods: {
    init () {
      myChart = echarts.init(document.getElementById('chart'))
      this.setOption()
    },
    setOption () {
      let data = this.data
      myChart.setOption({
        grid: {
          top: 20,
          bottom: 20,
          left: 40,
          right: 10
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          axisTick: { show: false },
          axisLine: { show: false },
          data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        },
        yAxis: {
          type: 'value',
          axisTick: { show: false },
          axisLine: { show: false },
          splitLine: {
            lineStyle: {
              color: '#ededed'
            }
          },
          axisLabel: {
            formatter (value) {
              let v = value.toString()
              return value >= 10000 ? `${v.substr(0, v.length - 4)}万` : v
            }
          }
        },
        series: [
          {
            type: 'line',
            symbolSize: 4,
            symbol: 'circle',
            itemStyle: { color: '#256EF6' },
            lineStyle: {
              normal: {
                width: 1,
                color: '#256EF6'
              }
            },
            areaStyle: {
              normal: {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0, color: 'rgba(37,110,246,.2)'
                    }, {
                      offset: 1, color: 'rgba(37,110,246,0)'
                    }
                  ]
                }
              }
            },
            data
          }
        ]
      })
    }
  }
}
</script>
<style scoped>
#chart {
  width: 100%;
  height: 4rem;
}
</style>
