<template>
  <div class="wishing">
    <p class="title">最后，许个心愿吧！</p>
    <p>2018我为世界付出了太多，</p>
    <p>2019年要对自己更好点，让我许个小心愿，</p>
    <p>迎接完美的新一年！</p>
    <slot></slot>
  </div>
</template>

<style lang="scss">
.wishing {
  position: absolute;
  top: .96rem;
  bottom: 0;
  left: 0;
  right: 0;
  color: #FFD1B0;
  font-size: .32rem;
  .title {
    color: #FFC000;
    font-size: .48rem;
    margin-bottom: .2rem;
  }
  .sub-title {
    margin-top: .6rem;
    position: relative;
    >:first-child {
      display: inline-block;
      padding: 0 10px;
      background-color: #f9635a;
      z-index: 1;
      position: relative;
    }
    &::before, &::after {
      content: "";
      display: inline-block;
      height: 1px;
      background-color: #FFC000;
      position: absolute;
      left: 0;
      right: 0;
    }
    &::before { top: 34% }
    &::after { bottom: 34% }
  }
}
</style>
