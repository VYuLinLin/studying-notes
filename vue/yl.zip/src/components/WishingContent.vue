<template>
  <div class="wishing-content" ref="wishings">
    <p v-for="(item, k) in wishings" :key="k" :style="{'marginTop': `${k}rem`}">
      <span v-for="(text, i) in item.split('、')" :key="i" class="wishing-btn" @click="$emit('click', text)">{{ text }}</span>
    </p>
  </div>
</template>
<script>
export default {
  name: 'WishingContent',
  data () {
    return {
      wishings: [
        '步步高升、健健康康、每天被自己美醒、狂吃不胖、吃得饱睡得好、天天睡到自然醒、走遍全球、钱包变胖我变瘦',
        '心想事成、学业有成、涨工资、精通十八门外语、被表白、开心就好、女神爱我、男神爱我',
        '练出马甲线、要啥有啥、人见人爱、逢考必过、步步高升、阖家幸福、没有烦恼',
        '不熬夜、脱单、家人健康、顺顺利利、颜值爆表、你好我好大家好、锦鲤附身',
        '万事如意、肤白貌美、脱脂不脱发、世界和平、逆风翻盘、股票大涨、家和万事兴'
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
@keyframes scroll {
  0% {
    transform: translateX(100vw) }
  100% {
    transform: translateX(-100%) }
}
@mixin setScroll($top, $eq) {
  margin-top: $top;
  animation: scroll #{$eq}s linear infinite;
}
.wishing-content {
  margin-top: .6rem;
  >:nth-child(1) { @include setScroll(0, 16); }
  >:nth-child(2) { @include setScroll(1, 20); }
  >:nth-child(3) { @include setScroll(1, 10); }
  >:nth-child(4) { @include setScroll(1, 25); }
  >:nth-child(5) { @include setScroll(1, 14); }
  p {
    height: 1rem;
    display: flex;
    align-items: center;
    position: absolute;
    transform: translateX(100vw);
  }
}
</style>
