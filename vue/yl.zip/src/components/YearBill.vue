<template>
  <main class="year-bill" ref="yearBill">
    <span class="audio-off" :class="{'audio-on': onOffAudio}" @click="changeAudio" key="audio">
      <audio ref="myAudio" :src="music" controls loop preload="none"></audio>
    </span>
    <transition :name="transtionDirection">
      <BillShell :index="cureentPage" :key="cureentPage">
        <!-- 0 -->
        <div v-if="!cureentPage">
          <span class="nf-logo"></span>
          <div class="home-fireworks"></div>
          <button class="open_bill" @click="getBillData">立即打开账单</button>
        </div>
        <!-- 01 -->
        <div class="content" v-show="cureentPage === 1">
          <p>截止至2018年12月31日，您已与南方基金同行<span class="red">{{ billData.opendays }}天</span>，感谢您选择了南方基金。</p>
          <p>截止2018年底南方基金已服务超<span class="red">6000万</span>以上客户。</p>
        </div>
        <!-- 02 -->
        <div class="content" v-show="cureentPage === 2">
          <p>这一年，您登录了
            <span class="red">{{ billData.logintimes }}次</span>
            <template v-if="billData.logintimes >= 50">，超过了<span class="red">{{ billData.loginrate }}%</span>的客户</template>。
          </p>
          <p>您喜欢在{{ billData.loginpreference }}登录，<span class="red">{{ billData.loginpreferencerate }}%</span>的客户与您有着相同的习惯。</p>
        </div>
        <!-- 03 -->
        <div class="content" v-show="cureentPage === 3">
          <p>这一年，您共投资了<span class="red">{{ billData.investfundnum }}只</span>基金，投资总金额<span class="red">{{ billData.investamt | formatSum }}元</span>。</p>
          <p v-if="billData.intelibuyname">在<span class="red">{{ billData.intelibuydate }}</span>，通过智能认购<span class="red">{{ billData.intelibuyname }}</span>基金<span class="red">{{ billData.intelibuyamt | formatSum }}元</span>，有没有觉得多赚了一点点呢？</p>
        </div>
        <!-- 04 -->
        <div class="content" v-show="cureentPage === 4">
          <p>您于<span class="red">{{ billData.maxredeemdate }}</span>，赎回<span class="red">{{ billData.maxredeemname }}</span>基金<span class="red">{{ billData.maxredeemamt | formatSum }}元</span>是您全年最大一笔货币基金赎回。我们已把普通赎回资金到账时间提前到了7点左右，一睁眼就看到钱到账的感觉是不是很开森？</p>
          <p>2018年我们上线了智能快取，最高快赎额度可达<span class="red">8万元</span>。</p>
        </div>
        <!-- 05 -->
        <div v-show="cureentPage === 5">
          <div class="content" v-if="billData.aipnum || billData.aipamt || billData.aipname">
            <p>2018年您共定投<span class="red">{{ billData.aipnum }}次</span>，定投金额<span class="red">{{ billData.aipamt | formatSum }}元</span>，<span class="red">{{ billData.aipname }}</span>基金是您的定投最爱。</p>
          </div>
          <div class="content" v-else>
            <p>2018年您未定投基金哦～</p>
            <p>基金定投具有省时省力，强制储蓄，平摊风险和成本等优势。市场低位是定投布局好时机哦~</p>
          </div>
          <div class="content content2" v-if="billData.aipnum || billData.aipamt || billData.aipname">基金定投具有省时省力，强制储蓄，平摊风险和成本等优势。</div>
        </div>
        <!-- 06 -->
        <div class="content" v-show="cureentPage === 6">
          <p>截止至2018年12月31日，您历史上盈利最多的基金是<span class="red">{{ billData.incomemaxfundname }}</span>，盈利<span class="red">{{ billData.incomemax | formatSum }}元</span>。</p>
          <p v-if="billData.cdrincome">2018年您共投资<span class="red">南方战略配售</span>基金<span class="red">{{ billData.cdrinvestamt | formatSum }}元</span>，您是行业创新坚定的支持者，感谢您的积极参与，截止2018年底盈利<span class="red">{{ billData.cdrincome | formatSum }}元</span>。</p>
        </div>
        <!-- 07 -->
        <div class="content" v-show="cureentPage === 7">
          <template v-if="formatTime(billData.cctouchtime)">
            <p><span class="red">{{ billData.ccfirsttouch }}</span></p>
            <p>您全年第一次联系南方基金，累计跟客服MM聊了<span class="red">{{ formatTime(billData.cctouchtime) }}</span>，您的每个问题我们都会全力以赴。</p>
          </template>
          <p v-else>2018年您还未与南方基金取得联系，欢迎通过南方基金微信公众号[客户服务]-[微客服]，或拨打400-889-8899联系我们，还有24h智能机器人随时待命为您服务~</p>
        </div>
        <!-- 08 -->
        <div class="details" v-show="cureentPage === 8">
          <div class="header">
            <p>您2018年年末资产为<span class="red">{{ billData.monthasset | formatSum }}元</span>，
              <template v-if="billData.monthasset > 500000">土豪我们做个朋友吧</template>
              <template v-else>致富指日可待</template>~
            </p>
          </div>
          <div class="line-chart">
            <p>每月末资产</p>
            <LineChart v-if="cureentPage === 8" :data="billData.monthassets"></LineChart>
          </div>
        </div>
        <!-- 09 -->
        <Wishing v-show="cureentPage === 9">
          <div class="sub-title" v-if="wishingText"><p>2019 年我希望</p></div>
          <div class="sub-title" v-else><p>心愿循环中，<span class="yellow">点击</span>选一个吧</p></div>
          <div class="mt50" v-if="wishingText">
            <p class="yellow f30 mb50 mt20">{{ wishingText }}</p>
            <span class="wishing-btn" @click="wishingText=''">重新选择愿望</span>
            <span class="wishing-btn" @click="goBackTo(1)">回看账单</span>
          </div>
          <WishingContent v-else @click="changeNextPage"></WishingContent>
        </Wishing>
      </BillShell>
    </transition>
    <footer class="footer" v-if="cureentPage && cureentPage < 9">
      <span class="pull_down" @click="changeNextPage()"></span>
    </footer>
  </main>
</template>

<script>
import axios from 'axios'
import BillShell from './BillShell'
import LineChart from './LineChart'
import Wishing from './Wishing'
import WishingContent from './WishingContent'
export default {
  name: 'YearBill',
  components: {
    BillShell,
    LineChart,
    Wishing,
    WishingContent
  },
  data () {
    let text = localStorage.getItem('wishingText')
    return {
      onOffAudio: false,
      music: process.env.VUE_APP_MUSIC,
      transtionDirection: 'up', // 过渡方向
      cureentPage: 0, // 当前页面
      billData: {},
      wishingText: typeof text !== 'object' ? text : ''
    }
  },
  filters: {
    formatSum (value) {
      if (escape(value).indexOf('%u') !== -1) return value
      if (!value) return '0.00'
      return Number(value).toFixed(2)
    }
  },
  watch: {
    // 不满足条件省略
    cureentPage (n, old) {
      const isPlus = n > old
      const { logintimes, investamt, maxredeemamt, incomemax } = this.billData
      let flag = 0
      if (n === 2) {
        // 登录0次
        !Number(logintimes) && flag++
      } else if (n === 3) {
        // 总投资为0
        !Number(investamt) && flag++
      } else if (n === 4) {
        // 赎回货币基金为0
        !Number(maxredeemamt) && flag++
      } else if (n === 6) {
        // 盈利最多的基金为负数
        incomemax < 0 && flag++
      }
      flag && (this.cureentPage = isPlus ? n + 1 : n - 1)
    }
  },
  mounted () {
    this.init()
  },
  methods: {
    // 滑动进入下一页
    init () {
      let el = this.$refs.yearBill
      let touchY = 0
      let touchEndFlag = false
      el.addEventListener('touchstart', e => {
        touchY = e.touches[0].clientY
      })
      el.addEventListener('touchend', e => {
        const index = this.cureentPage
        const y = e.changedTouches[0].clientY - touchY
        if (!index || touchEndFlag) return
        if (Math.abs(y) < 40) return
        if (y > 0 && index > 1) {
          this.transtionDirection = 'down'
          this.cureentPage--
        } else if (y < 0 && index < 9) {
          this.transtionDirection = 'up'
          this.cureentPage++
        }
        touchEndFlag = true
        setTimeout(() => {
          touchEndFlag = false
        }, 1000)
      })
    },
    // 音乐开关
    changeAudio () {
      this.onOffAudio = !this.onOffAudio
      const audio = this.$refs.myAudio
      this.onOffAudio ? audio.play() : audio.pause()
    },
    // 点击进入下一页
    changeNextPage (text) {
      if (this.cureentPage === 9 && !text) return
      if (text && typeof text === 'string') {
        this.wishingText = text
        localStorage.setItem('wishingText', text)
      }
      this.transtionDirection = 'up'
      this.cureentPage < 9 && this.cureentPage++
    },
    // 回看账单
    goBackTo (num) {
      this.cureentPage = num
      this.transtionDirection = 'down'
    },
    // 请求数据
    getBillData () {
      if (!window.activeInfo.sessionkey) {
        this.nfActivityJs.goNfPage('LoginPage')
        return
      }
      const data = {
        function: 'S053',
        channel: 'mweb',
        sessionkey: window.activeInfo.sessionkey
      }
      axios({
        method: 'post',
        url: process.env.VUE_APP_URL + '/nffund/nfEStationNewTrade/S053',
        data,
        transformRequest: [
          data => {
            // 将数据转换为表单数据
            let ret = ''
            for (let it in data) {
              ret +=
                encodeURIComponent(it) +
                '=' +
                encodeURIComponent(data[it]) +
                '&'
            }
            return ret
          }
        ]
      }).then(res => {
        let data = res.data
        if (data.code === 'ETS-5BP0000' && data) {
          if (data.annualbillinfo) {
            this.cureentPage++
            this.billData = data.annualbillinfo
          } else {
            this.$emit('input', false)
          }
        } else if (data.code === 'ETS-5BP9951') {
          this.nfActivityJs.toast(data.message)
          this.nfActivityJs.goNfPage('LoginPage')
        } else {
          this.nfActivityJs.toast(data.message ? data.message : '请求失败')
        }
      }).catch(err => {
        this.nfActivityJs.toast(err.message ? err.message : '请求失败')
      })
    },
    // 过滤时间
    formatTime (value) {
      let h = Math.floor(value / 3600) < 10 ? '0' + Math.floor(value / 3600) : Math.floor(value / 3600)
      let m = Math.floor((value / 60 % 60)) < 10 ? '0' + Math.floor((value / 60 % 60)) : Math.floor((value / 60 % 60))
      let s = Math.floor((value % 60)) < 10 ? '0' + Math.floor((value % 60)) : Math.floor((value % 60))
      let str = +h ? `${h}小时` : ''
      str += +m ? `${m}分钟` : ''
      str += +s ? `${s}秒` : ''
      return str
    }
  }
}
</script>

<style scoped lang="scss">
// 音乐
@keyframes autoloop {
  0% {
    transform: rotate(0deg) translateZ(0); }
  100% {
    transform: rotate(360deg) translateZ(0); }
}
// 下拉
@keyframes pull {
  0% {
    transform: translateY(0);
  }
  86% {
    transform: translateY(20px);
  }
  100% {
    transform: translateY(0);
  }
}
// 烟花
@keyframes fireworks {
  0%{
    transform: scale(0);
    opacity: 1;
  }
  80%{
    transform: scale(1);
    opacity: 1;
  }
  100%{
    opacity: 0;
  }
}
@mixin firework($img, $time) {
  content: '';
  display: inline-block;
  position: absolute;
  background: url('#{$imgUrl}/static/2018bill/img/firework_#{$img}.png') no-repeat center;
  background-size: contain;
  animation-name: fireworks;
  animation-duration: #{$time};
  animation-iteration-count: infinite;
}
.year-bill {
  height: 100%;
  font-size: 0.24rem;
  color: #333;
  text-align: center;
  overflow: hidden;
  /* 15px */
  font-size: 0.3rem;
  .up-enter-active,
  .up-leave-active,
  .down-enter-active,
  .down-leave-active {
    transition: all .4s linear;
  }
  .up-enter-to,
  .up-leave-to { transform: translateY(-100%) }
  .down-enter { transform: translateY(-200%) }
  .down-enter-to { transform: translateY(-100%) }
  .down-leave-to { transform: translateY(100%) }

  .nf-logo {
    display: inline-block;
    position: absolute;
    z-index: 1;
    width: 1.96rem;
    height: .42rem;
    top: .32rem;
    left: .32rem;
    background: url('#{$imgUrl}/static/2018bill/img/nf_logo.png') no-repeat center;
    background-size: contain;
  }
  .home-fireworks {
    position: relative;
    &::before {
      width: 1.44rem;
      height: 1.44rem;
      top: 1rem;
      left: .2rem;
      @include firework('1', 3s)
    }
    &::after {
      width: 1.54rem;
      height: 1.54rem;
      top: .36rem;
      right: .32rem;
      @include firework('2', 2.6s)
    }
  }
  .open_bill {
    position: fixed;
    bottom: 1.76rem;
    left: 0;
    right: 0;
    width: 37%;
    height: 0.8rem;
    line-height: 0.8rem;
    color: #fff;
    background: #cd454b;
    border-radius: 0.4rem;
    font-size: 0.32rem;
    margin: 0 auto;
  }
  .content {
    width: 50%;
    position: absolute;
    top: 2rem;
    left: 1.1rem;
    box-sizing: border-box;
    padding: 0.32rem;
    letter-spacing: 0;
    text-align: justify;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 5px;
  }
  .red {
    color: #dc3a35;
  }
  .yellow { color: #FFC000 }
  .audio-off {
    display: inline-block;
    width: .5rem;
    height: .5rem;
    padding: .1rem;
    position: absolute;
    z-index: 1;
    top: .32rem;
    right: .32rem;
    background: url('#{$imgUrl}/static/2018bill/img/audio_off.png') no-repeat center;
    background-size: .5rem;
    audio {
      display: none;
      pointer-events: none;
      z-index: -1;
    }
  }
  .audio-on {
    background-image: url('#{$imgUrl}/static/2018bill/img/audio_on.png');
    animation: autoloop 3s 0s linear infinite;
  }
  .footer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
  }
  .footer .pull_down {
    display: inline-block;
    width: 0.44rem;
    height: 0.44rem;
    margin-bottom: 0.6rem;
    background: url('#{$imgUrl}/static/2018bill/img/pull_down.png') no-repeat center;
    background-size: contain;
    animation: pull 1s linear infinite;
  }
}
</style>
