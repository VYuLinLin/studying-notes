import Vue from 'vue'
import App from './App.vue'
import './assets/css/reset.css'
import './assets/js/reset.js'
import { nfActivityJs } from './assets/js/activity.js'

Vue.config.productionTip = false
Vue.prototype.nfActivityJs = nfActivityJs
new Vue({
  render: h => h(App)
}).$mount('#app')
